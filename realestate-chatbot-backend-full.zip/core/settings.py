import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'dev-key-for-local'
DEBUG = True
ALLOWED_HOSTS = ['*']

INSTALLED_APPS = [
    'django.contrib.staticfiles',
    'rest_framework',
    'corsheaders',
    'api',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.common.CommonMiddleware',
]

ROOT_URLCONF = 'core.urls'
STATIC_URL = '/static/'

CORS_ALLOW_ALL_ORIGINS = True

DATA_PATH = os.environ.get('DATA_PATH', os.path.join(BASE_DIR, 'data', 'sample_data.xlsx'))
