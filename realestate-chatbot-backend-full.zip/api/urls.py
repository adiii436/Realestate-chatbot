from django.urls import path
from .views import analyze_view, upload_view

urlpatterns = [
    path('analyze/', analyze_view, name='analyze'),
    path('upload/', upload_view, name='upload'),
]
