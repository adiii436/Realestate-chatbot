import os
import pandas as pd
from django.conf import settings
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .serializers import UploadSerializer

def _load_data(excel_path):
    df = pd.read_excel(excel_path)
    df.columns = [c.strip().lower() for c in df.columns]
    return df

def _generate_summary(df_area, area_name):
    if df_area.empty:
        return f"No data found for {area_name}."
    years_sorted = sorted(df_area['year'].unique())
    first_year = years_sorted[0]
    last_year = years_sorted[-1]
    try:
        first_avg = df_area[df_area['year'] == first_year]['price'].mean()
        last_avg = df_area[df_area['year'] == last_year]['price'].mean()
        change = ((last_avg - first_avg) / first_avg) * 100 if first_avg else 0
    except Exception:
        change = 0
    if change > 5:
        price_desc = f"Prices in {area_name} are rising (about {change:.1f}% increase from {first_year} to {last_year})."
    elif change < -5:
        price_desc = f"Prices in {area_name} are declining (about {abs(change):.1f}% decrease from {first_year} to {last_year})."
    else:
        price_desc = f"Prices in {area_name} are fairly stable from {first_year} to {last_year}."
    try:
        first_dem = df_area[df_area['year'] == first_year]['demand'].mean()
        last_dem = df_area[df_area['year'] == last_year]['demand'].mean()
        dem_change = ((last_dem - first_dem) / first_dem) * 100 if first_dem else 0
    except Exception:
        dem_change = 0
    if dem_change > 5:
        demand_desc = f"Demand has increased (approx {dem_change:.1f}%)."
    elif dem_change < -5:
        demand_desc = f"Demand has decreased (approx {abs(dem_change):.1f}%)."
    else:
        demand_desc = "Demand is relatively steady."
    return f"{price_desc} {demand_desc}"

@api_view(['POST'])
def upload_view(request):
    serializer = UploadSerializer(data=request.data)
    if serializer.is_valid():
        f = serializer.validated_data['file']
        save_path = os.path.join(settings.BASE_DIR, 'data', f.name)
        with open(save_path, 'wb+') as dest:
            for chunk in f.chunks():
                dest.write(chunk)
        return Response({'status': 'ok', 'path': save_path})
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def analyze_view(request):
    data = request.data
    query = data.get('query', '')
    dataset_url = data.get('dataset_url')
    tokens = query.strip().split()
    if not tokens:
        return Response({'error': 'Empty query'}, status=400)
    area = tokens[-1]
    excel_path = dataset_url or settings.DATA_PATH
    if not os.path.exists(excel_path):
        return Response({'error': f'Dataset not found at {excel_path}'}, status=400)
    try:
        df = _load_data(excel_path)
    except Exception as e:
        return Response({'error': f'Failed to read dataset: {str(e)}'}, status=500)
    df_area = df[df['area'].str.lower().str.contains(area.lower())]
    summary = _generate_summary(df_area, area)
    if not df_area.empty:
        grouped = df_area.groupby('year').agg({'price': 'mean', 'demand': 'mean'}).reset_index()
        chart = {
            'years': grouped['year'].tolist(),
            'price': grouped['price'].round(2).tolist(),
            'demand': grouped['demand'].round(2).tolist()
        }
    else:
        chart = {'years': [], 'price': [], 'demand': []}
    table = df_area.to_dict(orient='records')
    return Response({'summary': summary, 'chart': chart, 'table': table})
