import React, { useState } from "react";
import axios from "axios";

function App() {
  const [query, setQuery] = useState("");
  const [response, setResponse] = useState(null);

  const handleAnalyze = async () => {
    const res = await axios.post("http://127.0.0.1:8000/api/analyze/", {
      query: query
    });
    setResponse(res.data);
  };

  return (
    <div style={{ padding: "30px", fontFamily: "Arial" }}>
      <h2>Real Estate Analyzer</h2>
      <input
        style={{ width: "300px", padding: "10px" }}
        placeholder="Enter your query (e.g., Show me prices in Wakad)"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <button
        onClick={handleAnalyze}
        style={{ marginLeft: "10px", padding: "10px 20px" }}
      >
        Analyze
      </button>

      {response && (
        <div style={{ marginTop: "20px" }}>
          <h3>Summary</h3>
          <p>{response.summary}</p>

          <h3>Data Table</h3>
          <pre>{JSON.stringify(response.table, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}

export default App;
